<?php
// opening php tags

session_start();

// adding database file
require_once("Placement_portal.php");

// Assuming $conn is the database connection object established in Placement_portal.php

$sql = "SELECT * FROM users";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "Name: " . $row['Name'] . "<br>";
        // Assuming 'Name' is a column in your 'users' table
        // You might want to replace 'Name' with the actual column names from your table
    }
} else {
    echo "No records found";
}

// closing php tags
?>
