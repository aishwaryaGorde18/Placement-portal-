
                                 SUDHEE'23 HACKATHON CBIT

                      A small portal for managing placement drives
